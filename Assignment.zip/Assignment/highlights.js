$(document).ready(function() {
    $("#slider").bxSlider({
        auto: true,
        pause: 2500,
        randomStart: true,
        minSlides: 1,
        maxSlides: 1,
        moveSlides: 1,
        captions: true,
        slideMargin: 20
    });
});